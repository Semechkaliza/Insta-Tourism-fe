#include <CTPP2.hpp>

// 1. Создаем коллектор результатов. Вывод направляем в STDOUT
FileOutputCollector oOutputCollector(stdout);

// 2. Создаем фабрику объектов
SyscallFactory oSyscallFactory(100);
// .... и загружаем стандартную библиотеку
STDLibInitializer::InitLibrary(oSyscallFactory);

// 3. Загружаем файл с диска
VMFileLoader oLoader(argv[1]);
// Получаем образ программы 
const VMMemoryCore * pVMMemoryCore = oLoader.GetCore();

/*
 * 4. Заполняем данные, которые хотим вывести.
 *    И если в прошлый раз мы добавляли их вручную,
 *    то сейчас используем для этого JSON
 */
CDT oHash;
CTPP2JSONFileParser oJSONFileParser(oHash);
oJSONFileParser.Parse(argv[2]);

// 5. Создаем виртуальную машину
VM oVM(oSyscallFactory);

// 6. Инициализируем машину для запуска программы
oVM.Init(oOutputCollector, *pVMMemoryCore);

// 7. Запускаем программу
UINT_32 iIP = 0;
oVM.Run(*pVMMemoryCore, iIP, oHash);
